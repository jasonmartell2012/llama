export const name = "Input";

export const importDocs = `
import { Input } from "/components/ui/input"
`;

export const usageDocs = `
<Input />
`;
